<thead class="sticky z-10 top-0 bg-white dark:bg-gray-900">
    {{ $slot }}
</thead>
